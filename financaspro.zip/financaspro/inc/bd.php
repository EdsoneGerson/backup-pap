<?php 
    $host = "localhost";
    $user = "root";
    $password = "";
    $bd = "pap";

    $ligacaodb = mysqli_connect($host, $user, $password, $bd);
?>